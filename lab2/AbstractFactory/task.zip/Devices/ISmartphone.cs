﻿public interface ISmartphone
{
    void ShowSpecs();
}
