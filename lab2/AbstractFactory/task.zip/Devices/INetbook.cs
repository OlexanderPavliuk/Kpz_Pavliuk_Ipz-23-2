﻿public interface INetbook
{
    void ShowSpecs();
}
