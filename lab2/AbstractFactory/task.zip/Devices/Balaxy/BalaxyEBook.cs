﻿public class BalaxyEBook : IEBook
{
    public void ShowSpecs() => Console.WriteLine("Balaxy EBook: OLED Screen for reading.");
}