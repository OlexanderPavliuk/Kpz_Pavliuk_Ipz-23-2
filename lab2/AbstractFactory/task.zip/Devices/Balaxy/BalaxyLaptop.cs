﻿public class BalaxyLaptop : ILaptop
{
    public void ShowSpecs() => Console.WriteLine("Balaxy Laptop: Premium Experience.");
}