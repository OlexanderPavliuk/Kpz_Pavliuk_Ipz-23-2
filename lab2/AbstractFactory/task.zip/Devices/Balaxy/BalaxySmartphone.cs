﻿public class BalaxySmartphone : ISmartphone
{
    public void ShowSpecs() => Console.WriteLine("Balaxy Smartphone: Powerhouse.");
}