﻿public class BalaxyNetbook : INetbook
{
    public void ShowSpecs() => Console.WriteLine("Balaxy Netbook: Modern Design.");
}