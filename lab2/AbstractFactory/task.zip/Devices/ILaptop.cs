﻿public interface ILaptop
{
    void ShowSpecs();
}