﻿public class KiaomiEBook : IEBook
{
    public void ShowSpecs() => Console.WriteLine("Kiaomi EBook: Simple and effective.");
}