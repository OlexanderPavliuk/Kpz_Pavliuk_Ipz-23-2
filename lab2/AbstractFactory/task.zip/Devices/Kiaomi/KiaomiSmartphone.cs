﻿public class KiaomiSmartphone : ISmartphone
{
    public void ShowSpecs() => Console.WriteLine("Kiaomi Smartphone: Budget Beast.");
}