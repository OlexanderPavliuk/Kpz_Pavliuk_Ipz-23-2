﻿public class KiaomiLaptop : ILaptop
{
    public void ShowSpecs() => Console.WriteLine("Kiaomi Laptop: Affordable performance.");
}