﻿public class KiaomiNetbook : INetbook
{
    public void ShowSpecs() => Console.WriteLine("Kiaomi Netbook: Portable and efficient.");
}