﻿public interface IEBook
{
    void ShowSpecs();
}
