﻿public class IProneEBook : IEBook
{
    public void ShowSpecs() => Console.WriteLine("IProne EBook: Retina Display, Long Battery.");
}