﻿public class IProneNetbook : INetbook
{
    public void ShowSpecs() => Console.WriteLine("IProne Netbook: Lightweight and Compact.");
}