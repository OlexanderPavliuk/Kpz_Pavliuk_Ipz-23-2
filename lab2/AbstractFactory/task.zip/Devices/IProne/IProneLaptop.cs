﻿public class IProneLaptop : ILaptop
{
    public void ShowSpecs() => Console.WriteLine("IProne Laptop: Fast & Sleek.");
}