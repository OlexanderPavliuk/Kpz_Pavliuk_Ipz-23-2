﻿public class IProneSmartphone : ISmartphone
{
    public void ShowSpecs() => Console.WriteLine("IProne Smartphone: Flagship Killer.");
}